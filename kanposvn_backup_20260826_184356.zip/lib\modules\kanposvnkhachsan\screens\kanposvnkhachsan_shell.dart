import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/auth/employee_auth.dart';
import '../../../core/auth/employee_role_policy.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/providers.dart';
import '../../../core/sync/api_config.dart';
import '../../../core/widgets/account_switcher_button.dart';
import '../providers/hotel_providers.dart';
import '../services/hotel_seed_data.dart';
import 'rooms_screen.dart';
import 'booking_screen.dart';
import 'checkin_checkout_screen.dart';
import 'hotel_finance_screen.dart';
import 'hotel_reports_screen.dart';
import 'hotel_settings_screen.dart';
import 'hotel_bill_search_screen.dart';
import 'hotel_customer_screen.dart';
import 'hotel_dashboard_screen.dart';

class KanPosVNKhachSanShell extends ConsumerStatefulWidget {
  const KanPosVNKhachSanShell({super.key});

  @override
  ConsumerState<KanPosVNKhachSanShell> createState() => _KanPosVNKhachSanShellState();
}

class _KanPosVNKhachSanShellState extends ConsumerState<KanPosVNKhachSanShell> {
  int _selectedIndex = 0;
  bool _isInit = false;
  String? _initError;

  @override
  void initState() {
    super.initState();
    _initData();
  }

  Future<void> _initData() async {
    try {
      final isarService = ref.read(hotelIsarServiceProvider);
      await HotelSeedData.seed(isarService);
      ref.read(hotelRoomsProvider.notifier).loadRooms();
      ref.read(hotelBookingsProvider.notifier).loadBookings();
      ref.read(hotelServiceItemsProvider.notifier).loadItems();
      ref.read(hotelCheckInsProvider.notifier).loadCheckIns();
      if (mounted) {
        setState(() {
          _isInit = true;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _initError = '$e');
    }
  }

  static final Map<String, Set<String>> _roleTabs = {
    EmployeeRoles.cashier: const {'dashboard', 'booking', 'checkin', 'bills', 'settings'},
    EmployeeRoles.sale: const {'dashboard', 'booking', 'checkin', 'customers', 'settings'},
    EmployeeRoles.warehouse: const {'settings'},
    EmployeeRoles.accountant:
        const {'dashboard', 'rooms', 'finance', 'reports', 'settings', 'bills'},
  };

  /// Định nghĩa các tab của module (id, icon, label) — thứ tự hiển thị.
  /// Dịch vụ / Thiết lập Giá / Quản Lý NV đã chuyển vào trong tab Cài Đặt.
  static final Map<String, ({IconData icon, String label})> _tabDefs = {
    'dashboard': (icon: Icons.dashboard, label: 'Dashboard'),
    'rooms': (icon: Icons.grid_view, label: 'Sơ đồ phòng'),
    'booking': (icon: Icons.book_online, label: 'Lễ tân / Đặt phòng'),
    'checkin': (icon: Icons.login, label: 'Check-in/Out'),
    'customers': (icon: Icons.people, label: 'Khách hàng'),
    'finance': (icon: Icons.account_balance, label: 'Thu Chi'),
    'reports': (icon: Icons.description, label: 'Báo cáo chung'),
    'bills': (icon: Icons.receipt_long, label: 'Tìm hóa đơn'),
    'settings': (icon: Icons.settings, label: 'Cài Đặt'),
  };

  static final Map<String, Widget Function()> _tabScreens = {
    'dashboard': () => const HotelDashboardScreen(),
    'rooms': () => const RoomsScreen(),
    'booking': () => const BookingScreen(),
    'checkin': () => const CheckinCheckoutScreen(),
    'customers': () => const HotelCustomerScreen(),
    'finance': () => const HotelFinanceScreen(),
    'reports': () => const HotelReportsScreen(),
    'bills': () => const HotelBillSearchScreen(),
    'settings': () => const HotelSettingsScreen(),
  };

  static final List<({String id, Widget screen, IconData icon, String label})>
      _allTabs = [
    for (final e in _tabDefs.entries)
      (
        id: e.key,
        screen: _tabScreens[e.key]!(),
        icon: e.value.icon,
        label: e.value.label,
      ),
  ];

  @override
  Widget build(BuildContext context) {
    if (!_isInit) {
      if (_initError != null) {
        return Scaffold(
          backgroundColor: AppColors.sidebarBg,
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.error_outline, color: AppColors.danger, size: 40),
                  const SizedBox(height: 12),
                  Text('Không thể nạp dữ liệu khách sạn',
                    style: TextStyle(
                      color: AppColors.textLight,
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                    )),
                  const SizedBox(height: 8),
                  Text(_initError!,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _initError = null;
                        _isInit = false;
                      });
                      _initData();
                    },
                    child: const Text('Thử lại'),
                  ),
                ],
              ),
            ),
          ),
        );
      }
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final isDesktop = MediaQuery.of(context).size.width > 800;
    final auth = ref.watch(authServiceProvider);
    final customTabs = auth.employeeAllowedTabs;
    final tabs = _allTabs.where((t) {
      if (auth.isManager) return true;
      // Tùy chỉnh tab riêng cho nhân viên (Owner check/uncheck trong "Quản Lý NV").
      if (customTabs != null) return customTabs.contains(t.id);
      return EmployeeRolePolicy.isAllowed(
        isManager: false,
        role: auth.employeeRole,
        tabId: t.id,
        roleTabs: _roleTabs,
      );
    }).toList();
    final safeIndex = tabs.isNotEmpty ? (_selectedIndex < tabs.length ? _selectedIndex : 0) : 0;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0284C7), // Blue theme for hotel
        foregroundColor: Colors.white,
        title: Row(
          children: [
            const Icon(Icons.hotel, color: Colors.white),
            const SizedBox(width: 8),
            const Text(
              'KanPosVN - Quản lý Khách sạn',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
          ],
        ),
        actions: [
          const AccountSwitcherButton(foregroundColor: Colors.white),
          IconButton(
            icon: const Icon(Icons.sync),
            tooltip: 'Đồng bộ Neon DB',
            onPressed: () async {
              final syncService = ref.read(hotelNeonSyncServiceProvider);
              // Assuming API URL and key are fetched from a config or environment
              final success = await syncService.triggerSync(ApiConfig.baseUrl, ApiConfig.syncApiKey);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(success ? 'Đồng bộ Neon DB qua Vercel API thành công!' : 'Đồng bộ thất bại, đã lưu vào Isar SyncQueue'),
                    backgroundColor: success ? Colors.green : Colors.orange,
                  ),
                );
              }
            },
          ),
        ],
      ),
      body: Row(
        children: [
          if (isDesktop)
            NavigationRail(
              selectedIndex: safeIndex,
              onDestinationSelected: (index) => setState(() => _selectedIndex = index),
              labelType: NavigationRailLabelType.all,
              scrollable: true,
              selectedIconTheme: const IconThemeData(color: Color(0xFF0284C7)),
              selectedLabelTextStyle: const TextStyle(color: Color(0xFF0284C7), fontWeight: FontWeight.bold),
              destinations: [
                for (final t in tabs)
                  NavigationRailDestination(icon: Icon(t.icon), label: Text(t.label)),
              ],
            ),
          if (isDesktop) const VerticalDivider(thickness: 1, width: 1),
          Expanded(child: ClipRect(child: tabs.isNotEmpty ? tabs[safeIndex].screen : const Text('Không có quyền truy cập tab'))),
        ],
      ),
      bottomNavigationBar: isDesktop
          ? null
          : BottomNavigationBar(
              currentIndex: safeIndex,
              onTap: (index) => setState(() => _selectedIndex = index),
              selectedItemColor: const Color(0xFF0284C7),
              unselectedItemColor: Colors.grey,
              type: BottomNavigationBarType.fixed,
              items: [
                for (final t in tabs)
                  BottomNavigationBarItem(icon: Icon(t.icon), label: t.label),
              ],
            ),
    );
  }
}

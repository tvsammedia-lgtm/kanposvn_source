import 'package:isar/isar.dart';

part 'nhathuoc_sync_model.g.dart';

@collection
class NhathuocSyncQueue {
  Id id = Isar.autoIncrement;

  DateTime updatedAt = DateTime.now();
  DateTime? deletedAt;
  String deviceId = "";
  int version = 1;
  
  String entityType = '';
  String entityId = ''; 
  String action = ''; // 'INSERT', 'UPDATE', 'DELETE'
  String payload = '';
  
  DateTime? createdAt;
  bool isSynced = false;
  
  int retryCount = 0;
  String lastError = '';
}
